package Services;

import org.springframework.beans.factory.annotation.Autowired;

import Common.Response;
import Dao.ATTDao;
import Request.LoginRequest;
import Response.LoginResponse;

public class ATTServiceImpl implements ATTService {

	@Autowired
	ATTDao attdao;
	
	public Response<LoginResponse> login(LoginRequest jsonData) {
		System.out.println("Login Service");
		 return attdao.login(jsonData);
		
	}
	

}
