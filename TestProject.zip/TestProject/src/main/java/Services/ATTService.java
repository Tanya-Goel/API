package Services;

import Common.Response;
import Request.LoginRequest;
import Response.LoginResponse;

public interface ATTService {

	Response<LoginResponse> login(LoginRequest jsonData);
	//public void login();
}
