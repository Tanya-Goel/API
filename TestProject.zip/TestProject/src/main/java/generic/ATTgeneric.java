package generic;

import java.util.List;

public interface ATTgeneric<T>{
	 public T findById(Class<T> persistentclass, Integer paramInt);
	  public T save(T paramObject);	 
	  public List<T> saveAll(List<T> paramList);
	//  public List<T> getAll(Class<T> persistentclass);
}
