package generic;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

@Component
public class ATTgenericImpl<T> implements ATTgeneric<T>{
	 @PersistenceContext
     private EntityManager em;
	 private Class<T> persistentClass;
	  
	  
	  public EntityManager getEm(){
	    return this.em;
	
	  }
	  
	  public void setEm(EntityManager em){
	    this.em = em;
	  }
	 
	  public Class<T> getPersistentClass() {
			return persistentClass;
		}

		public void setPersistentClass(Class<T> persistentClass) {
			this.persistentClass = persistentClass;
		}

	  
	  
		  
	  
	  @Transactional
	  public T save(T paramType){
	    paramType = this.em.merge(paramType);
	    return paramType;
	  }
	  
	  @Transactional
	  public T findById(Class<T> persistentClass , Integer id){
		  T result = this.em.find(persistentClass,id);
	    return result;
	  }
	 
	  
	  @Transactional
	  public List<T> saveAll(List<T> entityList){
	    for (T entity : entityList) {
	      entity = this.em.merge(entity);
	    }
	    return entityList;
	  }
	  
	/*  @Transactional
	  public List<T> getAll(Class<T> persistentClass){
		  CriteriaQuery<T> cre = this.em.getCriteriaBuilder().createQuery(persistentClass);
		  cre.select(cre.from(persistentClass));
		  CriteriaQuery<T> cre = this.em.getCriteriaBuilder().createQuery(persistentClass);
		  List<T> result = em.createQuery(cre).getResultList();
		  return result;
	  }
*/
	 
}


