package Common;

import java.util.List;

public interface ATTCommonDao {

	List<Object[]> getEmpRecord(String empId);

}
