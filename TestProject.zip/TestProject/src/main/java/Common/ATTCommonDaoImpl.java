package Common;

import java.util.List;

import javax.persistence.Query;
import javax.transaction.Transactional;

import generic.ATTgenericImpl;

public class ATTCommonDaoImpl extends ATTgenericImpl<Object> implements ATTCommonDao{

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Object[]> getEmpRecord(String empId) {
		String sql = "SELECT l.id,l.emp_id,l.username,l.password from User_Login l"
				+ "  where l.emp_id = '"+empId+"'";
		Query query = getEm().createNativeQuery(sql);
		List<Object[]> resultlist = query.getResultList();
		return resultlist;
	}

}
