package Dao;

import Common.Response;
import Request.LoginRequest;
import Response.LoginResponse;

public interface ATTDao {

	Response<LoginResponse> login(LoginRequest jsonData);

}
