package Dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;


import Common.ATTCommonDao;
import Common.Response;
import Request.LoginRequest;
import Response.LoginResponse;

public class ATTDaoImpl implements ATTDao {

	@Autowired
	ATTCommonDao attcommondao;
	
	public Response<LoginResponse> login(LoginRequest jsonData) {
		//System.out.println("Login Dao");
		Response<LoginResponse> response = new Response<LoginResponse>();
		List<LoginResponse> wrappedlist = new ArrayList<LoginResponse>();
		boolean flag = false;
		Map<String, String> errorMap = new HashMap<String, String>();
		try {
		
			List<Object[]> empRecordlist= attcommondao.getEmpRecord(jsonData.getEmpId());
		
		if(empRecordlist.size()!=0) {
			for(Object[] obj : empRecordlist) {
				
				LoginResponse res = new LoginResponse();
				res.setUserName(obj[2].toString());
				//System.out.println("Empid-- "+obj[1].toString());
				//System.out.println("Password-- "+obj[3].toString());
			
				wrappedlist.add(res);
			}
			flag = true;
			response.setResponseCode("100000");
			response.setResponseDesc("SUCCESS");
		}
		else {
			flag =true;
			response.setResponseCode("100000");
			response.setResponseDesc("NO RECORD FOUND");
		}
		response.setWrappedList(wrappedlist);
		}
		catch(Exception e) {
			errorMap.put("Database Error", e.getMessage());
			flag = false;
			response.setResponseCode("-100003");
			response.setResponseDesc("FAILURE");
			response.setErrorsMap(errorMap);
		}
		
		
		return response;
	}

}
