package Controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import Common.Response;
import Request.LoginRequest;
import Response.LoginResponse;
import Services.ATTService;

@Controller
@Path("attendance")
public class ATTController {

	@Autowired
	ATTService attservice;
	
	
	@POST
	//@GET
	@Path("/login")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response<LoginResponse> login(LoginRequest jsonData) {
		System.out.println(jsonData.getEmpId()+" ---  "+jsonData.getPassword());
		//System.out.println("Login COntroller");
		return attservice.login(jsonData);
	}
	
}
